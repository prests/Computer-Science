import hw3_util
teams = hw3_util.read_fifa()
id1= raw_input("Team 1 id => ")
print id1
id2= raw_input('Team 2 id => ')
print id2
print ''
print "Team"," "*14,"Win"," ","Draw ","Lose ","GF"," "*2,"GA"," "*2,"Pts"," ","GD"," "*2
id1 = int(id1)
id2 = int(id2)
team1 = teams[id1]
team2 = teams[id2]
GD1 = team1[5]-team1[6]
GD2 = team2[5]-team2[6]
team1str = str(team1[0])+' '*(20-len(str(team1[0])))+(str(team1[1])+' '*(6-len(str(team1[1]))))+(str(team1[2])+' '*(6-len(str(team1[2]))))+(str(team1[3])+' '*(6-len(str(team1[3]))))+(str(team1[4]))+' '*(6-len(str(team1[4])))+(str(team1[5])+' '*(6-len(str(team1[5]))))+(str(team1[6])+' '*(6-len(str(team1[6]))))+str(GD1)+ ' '*(6-len(str(GD1)))
team2str = str(team2[0])+' '*(20-len(str(team2[0])))+(str(team2[1])+' '*(6-len(str(team2[1]))))+(str(team2[2])+' '*(6-len(str(team2[2]))))+(str(team2[3])+' '*(6-len(str(team2[3]))))+(str(team2[4]))+' '*(6-len(str(team2[4])))+(str(team2[5])+' '*(6-len(str(team2[5]))))+(str(team2[6])+' '*(6-len(str(team2[6]))))+str(GD2)+ ' '*(6-len(str(GD1)))

if(team1[1]==team2[1]):
    if(GD1==GD2):
        if(team1[4]==team2[4]):
            print team1str
            print team2str
            print "They're Equal"
        elif(team1[4]>team2[4]):
            print team1str
            print team2str
            print team1[0],"is better"
        else:
            print team2str
            print team1str
            print team2[0],"is better"
    elif(GD1>GD2):
        print team1str
        print team2str
        print team1[0],"is better"
    else:
        print team2str
        print team1str
        print team2[0],"is better"
elif(team1[1]>team2[1]):
    print team1str
    print team2str
    print team1[0],"is better"
else:
    print team2str
    print team1str
    print team2[0],"is better"