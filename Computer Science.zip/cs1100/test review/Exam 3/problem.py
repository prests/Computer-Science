"""
People walk for a given set of steps, when they are within
the radius of a ball, they touch the ball. Simulation goes
until everyone stopped walking.


Which balls are touched at the end of simulation?
Which balls are not touched at the end of simulation?
Which people have which balls in common?

people.txt:
name|x|y|dx|dy|num_steps_to_move

balls.txt
ball name|color|x|y|radius

How many of each color?
Which colors are unique?

"""

from People import *
from Ball import *


if __name__ == "__main__":
    balls = []
    f = open('balls.txt')
    for line in f:
        m = line.strip().split("|")
        b = Ball(m[0], m[1], m[2], m[3], m[4])
        balls.append(b)    
    
    people = []
    for line in open('people.txt'):
        m = line.strip().split("|")
        p = People(m[0],m[1],m[2],m[3],m[4],m[5])
        people.append(p)
        
    ## keep track of how many people are moving
    nummoving = len(people)
    
    time = 0
    while nummoving > 0:
        time += 1
        
        ## move each person once
        for p in people:
            if p.ismoving:
                p.move()    
                if time >= p.steps:
                    p.ismoving = False
                    nummoving -= 1
                    print "Stopped at time %d ==>" %time, p
        
        for p in people:
            for b in balls:
                if b.withinregion(p.x,p.y):
                    p.touchball(b)
                    
                    
    for p in people:
        print p.name, "was near following balls:", 
        for bname in p.balls:
            print bname,
        print