stri = 'hello'
stri =stri.capitalize()
print stri
