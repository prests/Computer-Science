

class Ball(object):
    def __init__(self,name,color,x,y,radius):
        self.name = name
        self.color = color
        self.x = int(x)
        self.y = int(y)
        self.radius = int(radius)
    def __str__(self):
        return "Ball %s (%s) at (%d,%d) radius: %d" \
        %(self.name, self.color, self.x, self.y, self.radius)
    def withinregion(self, x, y):
        d = ((self.x-x)**2 + (self.y-y)**2)**(0.5)
        if d <= self.radius:
            return True
        else:
            return False

if __name__ == "__main__":
    balls = []
    f = open('balls.txt')
    for line in f:
        m = line.strip().split("|")
        b = Ball(m[0], m[1], m[2], m[3], m[4])
        balls.append(b)
        
    ##Find colors that are only used once!
    allcolors = {} ##key: color, value: #times color is used
    ## find how many times each color occurs
    for b in balls:
        c = b.color
        if c in allcolors:
            allcolors[c] += 1
        else:
            allcolors[c] = 1
    
    ##find all colors that occur only once
    for c in sorted(allcolors):
        if allcolors[c] == 1:
            print c