"""
Files:

- open it
- iterate through it
- close it

Containers:

Lists**
Sets
Dictionaries


Classes

"""


animals1 = ['cat', 'dog', 'bird']
animals2 = ['cat', 'cat', 'dog', 'dog', 'parrot']

print animals1[0], animals1[1]


animals3 = animals1 
## animals3 is an alias to animals1

## animals is a copy of animals2
animals4 = list(animals2)
animals4 = animals2[:]
print animals2
print animals4

##sets
## 

animals2set = set(animals2)
print animals2set

for a in animals2set:
    print "***", a
    
##print set in sorted order

atemp = list(animals2set)
atemp.sort()

for a in atemp:
    print ">>>", a
    
print sorted(animals2set)

for a in sorted(animals2set):
    print "###", a
    
##you can only put hashable things in a set
##integer, string, tuple of simple values
    
"""
Set functions

a = set()
a.add(1)
a.remove(2) ##2 must be in a
a.discard(2) ##no error if 2 is not in a


1 in a    ## O(1) if a is a set, O(n) if a is a list
2 not in a  ## O(1) if a is a set

a = set([1,2,3,4])
b = set([3,4,5,6])

c = a&b ## intersection: new set of common values in a and b

d = a|b ## union: all elements in a or b
e = a-b ## values from a that are not in b

## a-b is not necessarily the same as b-a

"""

a = set([1,2,3,4])
aa = a ## aa is an alias

bb = set(a) ##bb is a copy of values from a


"""

Dictionaries:

Set + additional data

Dictionary keys are stored as a set



"""

balls = {}
balls['balsy'] = 'red'
balls['roller'] = 'blue'
balls['bouncy'] = 'red'


"""
key in dictionary ## set operation O(1)

balls.keys() creates a list containing 
the keys in the dictionary

balls.values() creates a list containing
the values in the dictionary
"""

for key in balls: ##there is no ordering to keys as keys are stored as a set
    print key, balls[key]
    
for key in balls.keys():
    print key, balls[key]
    
for key in sorted(balls):
    print "***", key, balls[key]