
class People(object):
    def __init__(self,name,x,y,dx,dy,steps):
        self.name = name
        self.x = int(x)
        self.y = int(y)
        self.dx = int(dx)
        self.dy = int(dy)
        self.steps = int(steps)
        self.ismoving = True
        self.balls = set([])
        
    def __str__(self):
        return '%s at (%d,%d) moving (%d,%d) for %d steps'\
               %(self.name, self.x, self.y, self.dx, self.dy, self.steps)
    
    def move(self):
        self.x += self.dx
        self.y += self.dy
    def touchball(self, b):
        self.balls.add( b.name )
        
    
if __name__ == "__main__":
    people = []
    for line in open('people.txt'):
        m = line.strip().split("|")
        p = People(m[0],m[1],m[2],m[3],m[4],m[5])
        people.append(p)
        
    for p in people:
        print p