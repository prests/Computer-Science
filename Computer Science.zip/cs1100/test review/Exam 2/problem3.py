def time_add(cur_time,mins):
    hours = mins/60
    minutes = mins%60
    cur_time[0] = cur_time[0]+hours
    cur_time[1] = cur_time[1]+minutes
    if(cur_time[1]>=60):
        hours = cur_time[1]/60
        minutes = cur_time[1]%60
        cur_time[0]= cur_time[0]+hours
        cur_time[1]= minutes
    if(cur_time[0]>=24):
        cur_time[0]= cur_time[0]-24
    return cur_time

cur_time = [14,0]
cur_time = time_add(cur_time,90)
print cur_time