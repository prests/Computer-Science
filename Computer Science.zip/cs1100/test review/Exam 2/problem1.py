def day_compare(d1,d2):
    if(int(d1[2])>int(d2[2])):
        return 1
    elif(int(d2(2))>int(d1(2))):
        return 2
    else:
        if(int(d1(0))>int(d2(0))):
            return 1
        elif(int(d2(0))>int(d1(0))):
            return 2
        else:
            if(int(d1(1))>int(d2(1))):
                return 1
            elif(int(d2(1))>int(d1(1))):
                return 2
            else:
                return 0

