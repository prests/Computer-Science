def total(prices):
    pricesum = 0
    for i in range(0,len(prices)):
        pricesum = pricesum + prices[i]
    return pricesum

def draw(items,prices):
    for i in range(0,len(prices)):
        pricestring = '$'+str(prices[i])
        string = str(items[i]+' '*(14-(len(pricestring)+(len(items[i]))))+pricestring)
        print string
    print '-'*14
    pricesum = '$'+str(total(prices))
    string = str('Total'+' '*(14-(len('Total')+len(pricesum)))+pricesum)
    print string
        
items = ['Natto','Durian','Vegemite']
prices = [3,6,5]
draw(items,prices)