def is_reverse(word1,word2):
    temp = ''
    for i in range(len(word2)-1,-1,-1):
        temp = temp+word2[i]
    if(word1==temp):
        return True
    else:
        return False

word1 = 'drawer'
word2 = 'reward'
lol = is_reverse(word1,word2)
print lol