import textwrap

def find_top_ten():
    villains = []
    info = []
    for line in open('DrWhoVillains.tsv'):
        temp = line.strip().split('\t')
        if(temp[6]!='Stories, total'):
            info = [int(temp[6]),temp[0]]
            villains += info,
    villains.sort(reverse=True)
    for i in range(0,10):
        print '%d. '%(i+1),villains[i][1]
    return villains

def similair_stories(name,find):
    villain_stories = {}
    for line in open('DrWhoVillains.tsv'):
        story_titles = set()
        temp = line.strip().split('\t')
        if(temp[6]!='Stories, total'):
            stories = temp[8].split(',')
            for i in range(0,len(stories)):
                story_titles.add(stories[i].lstrip())
            villain_stories[temp[0]]= story_titles
    if(find == 'sim'):
        similair_villains = []
        for i in villain_stories:
            if(len(villain_stories[name].intersection(villain_stories[i]))>0):
                similair_villains += [i]
        similair_villains.sort()
        return similair_villains
    else:
        diff_villains = []
        for i in villain_stories[name]:
            count = 0
            for j in villain_stories:
                if(j==name):
                    continue
                for k in villain_stories[j]:
                    if(i==k):
                        count+=1
            if(count==0):
                diff_villains += [i]
        diff_villains.sort()
        return diff_villains
    
while(True):
    villains = find_top_ten()
    print 'Please enter a number between 1 and 10, or -1 to end'
    num = raw_input("Enter a villain => ")
    print num
    if(num.isdigit()==True):
        num = int(num)
        if(num == -1):
            print 'Exiting'
            break
        elif(num>10):
            num=10
        print villains[num-1][1],'in',villains[num-1][0],'stories, with the following other villains:'
        print '='*50
        sim_villains = similair_stories(villains[num-1][1],'sim')
        string = ''
        for i in sim_villains:
                string += i+', '
        string = string.strip().strip(',')
        for i in textwrap.wrap(string,70):
            print str('\t'+i)
        print
        diff = similair_stories(villains[num-1][1],'diff')
        if(len(diff)!=0):
            print 'The stories that only features',villains[num-1][1],'are:'
            print '='*50
            string = ''
            for i in diff:
                string += i+', '
            string = string.strip().strip(',')
            for i in textwrap.wrap(string,70):
                print str('\t'+i)
        else:
            print 'There are no stories with only this villain'
            print '='*50
    else:
        print 'Did not enter a digit'