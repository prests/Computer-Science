"""Author: Shayne Preston prests@rpi.edu

Purpose: Using the same method to assign stories to villains as in part1. I was able to check and compare the stories of the villain inputed with every villain in the file. Then adding to a counter and printing '*'*counter.

"""

#Imports
import textwrap
import collections

#Functions
def stories():
    villain_stories = {}
    #parses file
    for line in open('DrWhoVillains.tsv'):
        story_titles = set()
        temp = line.strip().split('\t')
        if(temp[6]!='Stories, total'):
            stories = temp[8].split(',')
            for i in range(0,len(stories)):
                story_titles.add(stories[i].strip())
            villain_stories[temp[0]]= story_titles #assign stories to all villains
    return villain_stories

def printer(name,stories):
    counter = {}
    for i in stories[name]:#Counts number of villains per story
        counter[i]=1
    for i in stories:
        if(name!=i):
            for j in stories[i]:
                for k in stories[name]:
                    if(j==k):#checks if the story at a villain matches story at original villain
                        counter[k]+=1
    counter = collections.OrderedDict(sorted(counter.items()))#sort
    for i in counter:#print
        string = str(i+': '+'*'*counter[i])
        print string
                    
#Main
if __name__ == "__main__":
    name = raw_input('Enter name of villain => ')
    print name
    print
    string1 = str('Stories featuring '+name)
    print string1
    print '-'*len(string1)
    stories = stories()
    printer(name,stories)