def move(x,y,direction,amount):
    if(direction == 'up' and (y-amount)>=0):
        y -= amount
    elif(direction == 'left' and (x-amount)>=0):
        x -= amount
    elif(direction == 'down' and (y+amount)<=400):
        y += amount
    elif(direction == 'right' and (x+amount)<=400):
        x += amount
    else:
        print 'Please turn turtle before moving'
    return x,y,direction

def turn(direction):
    if(direction == 'up'):
        direction = 'left'
    elif(direction == 'left'):
        direction = 'down'
    elif(direction == 'down'):
        direction = 'right'
    else:
        direction = 'up'
    return direction
         
turtle = 200,200,'right'
cood = '('+str(turtle[0])+','+str(turtle[1])+')'
print 'Turtle:',cood,'facing:','right'
commands = []
temp = 0
while(temp<5):
    command = raw_input('Command (move,jump,turn) => ')
    print command
    if(str(command.upper()) == 'MOVE'):
        turtle = move(turtle[0],turtle[1],turtle[2],20)
        commands.append(command)
    elif(str(command.upper()) == 'JUMP'):
        turtle = move(turtle[0],turtle[1],turtle[2],50)
        commands.append(command)
    elif(str(command.upper()) == 'TURN'):
        turtle = turtle[0],turtle[1],turn(turtle[2])
        commands.append(command)
    else:
        commands.append(command)
    cood = '('+str(turtle[0])+','+str(turtle[1])+')'
    print 'Turtle:',cood,'facing:',turtle[2]
    temp +=1

print ''
print 'All commands entered',commands
commands = sorted(commands)
print "Sorted commands",commands