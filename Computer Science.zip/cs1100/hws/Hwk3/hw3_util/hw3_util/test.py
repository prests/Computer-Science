import hw3_util
teamsList = hw3_util.read_fifa()
def CheckTeams(teams):
    team1=int(float(raw_input("Team 1 id => ")))
    print team1
    team1=teams[team1]
    team2=int(float(raw_input("Team 2 id => ")))
    print team2
    team2=teams[team2]
    
    pts1=int(team1[2])*3+int(team1[3])
    print "Team"," "*14,"Win"," ","Draw ","Lose ","GF"," "*2,"GA"," "*2,"Pts"," ","GD"," "*2
    print str(str(team1[0])+' '*(20-len(team1[0]))+str(team1[2])),' '*(4-len(str(team1[2]))),team1[3],' '*(4-len(str(team1[3]))),team1[4],' '*(4-len(str(team1[4]))),team1[5],' '*(4-len(str(team1[5]))),team1[6],' '*(4-len(str(team1[6]))),pts1,' '*(4-len(str(pts1))),team1[5]-team1[6]
    
    pts2=int(team2[2])*3+int(team2[3])
    print str(str(team2[0])+' '*(20-len(team2[0]))+str(team2[1])),' '*(4-len(str(team2[2]))),team2[3],' '*(4-len(str(team2[3]))),team2[4],' '*(4-len(str(team2[4]))),team2[5],' '*(4-len(str(team2[5]))),team2[6],' '*(4-len(str(team2[6]))),pts2,' '*(4-len(str(pts2))),team2[5]-team2[6]
    
    
    if pts1>pts2:
        print team1[0],'is better'
    elif pts2>pts1:
        print team2[0],'is better'
    else:
        if team1[5]-team1[6]>team2[5]-team2[6]:
            print team1[0],'is better'
        elif team2[5]-team2[6]>team1[5]-team1[6]:
            print team2[0],'is better'
        else:
            print team1[5]
            if team1[5]>team2[5]:
                print team1[0],'is better'
            elif team2[5]>team1[5]:
                print team2[0],'is better'
            else:
                print team1[0],'and',team2[0],'are tied.'
print teamsList[6][1]
compareTeams(teamsList)