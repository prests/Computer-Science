def make_diamond(background,foreground,height):
    temp = 0
    while(temp<(height/2+1)):
        if(temp==2):
            left = str(background*(height-temp)+'o'+background*(temp))
            right = left[::-1]
            left = str(background*(height-temp)+foreground+background*(temp))
        else:
            left = str(background*(height-temp)+foreground+background*(temp))
            right = left[::-1]
        line = str(left+right)
        if(height%2==0 and temp==(height/2)-1):
            if(temp+1<10 and height>=10):
                line = str(' '+str(temp+1)+left+right)
            else:
                line = str(str(temp+1)+left+right)
            print line
            temp+=1
        if(temp+1<10 and height>=10):
            line = str(' '+str(temp+1)+left+right)
        else:
            line = str(str(temp+1)+left+right)
        print line
        temp+=1
    while(temp<height):
        left = str(background*(temp+1)+foreground+background*(height-(temp+1)))
        right = left[::-1]
        if(temp+1<10 and height>=10):
            line = str(' '+str(temp+1)+left+right)
        else:
            line = str(str(temp+1)+left+right)
        print line
        temp+=1

sumtorun=0
Background = raw_input('Background char => ')
print Background
Foreground = raw_input('Foreground char => ')
print Foreground
Height = raw_input('Height => ')
print Height
print ''
if(Height.isdigit()==True):
    sumtorun+=1
else:
    print "Please enter a number for height"
if(len(Background)==1):
    sumtorun+=1
else:
    print 'Please enter one character for background'
if(len(Foreground)==1):
    sumtorun+=1
else:
    print 'Please enter one character for foreground'
if(sumtorun==3):
    make_diamond(Background,Foreground,int(Height))