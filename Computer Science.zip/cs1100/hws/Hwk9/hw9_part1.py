import json
category = raw_input('Enter a category ==> ')
print category
cutoff = int(raw_input('Cutoff for displaying categories => '))
print cutoff
final_list = {}
for line in open('businesses.json'):
    line = json.loads(line)
    for j in line['categories']:
        if(j == category):
            for j in line['categories']:
                if j in final_list and j != category:
                    final_list[j] += 1
                else:
                    final_list[j] = 1

if(len(final_list)==0):
    print 'Searched category is not found'
else:
    print 'Categories co-occurring with %s:'%category
    unsort_list = []
    for i in final_list:
        if(final_list[i]>=cutoff):
            unsort_list.append((i,final_list[i]))
    sort_list = sorted(unsort_list)
    if(len(sort_list)==0):
        print 'None above the cutoff'
    else:
        for i in sort_list:
            str1 = i[0].rjust(30)+': '+str(i[1])
            print str1