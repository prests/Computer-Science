"""Author: Shayne Preston prests@rpi.edu

   Purpose: The purpoes of this lab is to print the names of the top n most popular
   babies for male and female. The text file is imported through a raw_input as well
   as an input for n. I had to flip the name and the popularity number so i could sort
   the lists of names by highest number first. The new list is then checked for the top
   n of male names and top n of females name. then printed

"""
#prints the top n number of baby names
def solve(lists,gender,numNames):
    count =0
    i=0
    string = ''
    while(count<int(numNames)):
        if(str(lists[i][1])==str(gender)):
            count+=1
            if(count%3==0 and count!=0):
                string = string+str(lists[i][2])+' ('+str(lists[i][0])+')\n'
            elif(count==int(numNames)):
                string = string+str(lists[i][2])+ ' ('+str(lists[i][0])+')'
            else:
                string = string+str(lists[i][2])+ ' ('+str(lists[i][0])+') '
        i+=1
    print string

if __name__ == "__main__":
    Filename = raw_input("File name => ")
    print Filename
    numNames = raw_input("How many names to display? => ")
    print numNames
    lists = []
    for line in open(Filename):
        lists = lists+[line.strip().split(',')]
    lists.sort()
    print
    #converts the str to an int and flipping them for sorting
    for i in range(0,len(lists)):
        temp = lists[i][0]
        lists[i][2]=int(lists[i][2])
        lists[i][0]=lists[i][2]
        lists[i][2]=temp
    lists.sort(reverse=True)
    print 'Top female names'
    solve(lists,'F',numNames)
    print 'Top male names'
    solve(lists,'M',numNames)