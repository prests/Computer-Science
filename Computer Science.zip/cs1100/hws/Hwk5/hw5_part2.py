"""Author: Shayne Preston prests@rpi.edu

   Purpose: The purpose was to find which candidate was likely to win based
   on representative votes. The program starts with asking for the info of a
   candidate (name,wins,ties,#repvotes). Then makes a board by checking the potential
   solutions of 4 representatives by taking the sumation of their wins*5+ties*2+(repvotes/2). 
   Then put into a function that prints out the board with some labeling.

"""
import math as m
#creates list of winning candidate for each senario and is stored in a list
def make_board(candidate1,candidate2):
    string = []
    temp = []
    for i in range(0,5):
        for j in range(0,5):
            if(i==j):
                candidate1temp=candidate1[0],candidate1[1],(int(candidate1[2])+1),(int(candidate1[3])+j)
                candidate2temp=candidate2[0],candidate2[1],(int(candidate2[2])+1),(int(candidate2[3])+i)
                sums= winner(candidate1temp,candidate2temp)
            if(i>j):
                candidate1temp=candidate1[0],candidate1[1],candidate1[2],(int(candidate1[3])+j)
                candidate2temp=candidate2[0],(int(candidate2[1])+1),candidate2[2],(int(candidate2[3])+i)                
                sums= winner(candidate1temp,candidate2temp)
            if(i<j):
                candidate1temp=candidate1[0],(int(candidate1[1])+1),candidate1[2],(int(candidate1[3])+j)
                candidate2temp=candidate2[0],candidate2[1],candidate2[2],(int(candidate2[3])+i)                
                sums= winner(candidate1temp,candidate2temp)
            if(sums[0]>sums[1]):
                temp = temp+[candidate1[0][:1]]
            if(sums[0]<sums[1]):
                temp = temp+[candidate2[0][:1]]
            if(sums[0]==sums[1]):
                temp = temp+['-']
        string = string + temp
        temp=[]
    return string

#prints the winning list with labels       
def print_board(board):
    print 'Votes| ','0',' '*2,'1',' '*2,'2',' '*2,'3',' '*2,'4',' '
    stringline = str('-'*5+'|'+'-'*25)
    print stringline
    for i in range(0,5):
        tempstr = str(' '*2+str(i)+' '*2+'|'+' '*2)
        for j in range(0,5):
            if(j==4):
                tempstr = tempstr+board[j+(5*i)]+ ' '*2
            else:
                tempstr = tempstr+board[j+(5*i)]+ ' '*4
        print tempstr

#calculates the candidates score best on representatives at various points      
def winner(candidate1,candidate2):
    sum1 = 5*int(candidate1[1])+int(candidate1[2])*2+m.trunc(int(candidate1[3])/2.0)
    sum2 = 5*int(candidate2[1])+int(candidate2[2])*2+m.trunc(int(candidate2[3])/2.0)
    return [sum1,sum2]

if __name__ == "__main__":       
    campaigninfo1 = raw_input("Enter candidate 1 stats ==> ")
    print campaigninfo1
    campaigninfo1=campaigninfo1.split(',')
    campaigninfo2 = raw_input("Enter candidate 2 stats ==> ")
    print campaigninfo2
    campaigninfo2=campaigninfo2.split(',')
    print "Columns are %s's"%campaigninfo1[0],"votes, rows are %s's"%campaigninfo2[0],"votes"
    board = make_board(campaigninfo1,campaigninfo2)
    print_board(board)