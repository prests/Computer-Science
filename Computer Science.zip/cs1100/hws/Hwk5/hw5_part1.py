"""Author: Shayne Preston prests@rpi.edu

   Purpose: The purpose of this part is to ask for a starting population for both
   bunnies and for foxes. The populations are then put into a function that checks
   if their 1.) the same 2.) the same value as last generation 3.) if the generation is
   100. The numbers are then put into a function which uses a formula to calculate 
   the population for the next generation.
   

"""
#calculates the population for next generation
def next_pop(bpop,fpop):
    bpop_next = int(max(0,round((10*bpop)/(1+0.1*bpop)-.05*bpop*fpop)))
    fpop_next = int(max(0,round(.4*fpop+.02*fpop*bpop)))
    return (bpop_next,fpop_next)

#checks for a convergence with either bpop=fpop bpop=bpop_next fpop=fpop_next or count==100
def check_convergence(bpop,fpop):
    bpop=int(bpop)
    fpop=int(fpop)
    count = 0
    while(count<100):
        population = next_pop(bpop,fpop)
        bpop1=population[0]
        fpop1=population[1]
        count+=1
        if(bpop1==bpop and fpop1==fpop):
            return True,bpop1,fpop1,count
        bpop=bpop1
        fpop=fpop1
        if(bpop==0 or fpop==0):
            return True,bpop,fpop,count
    return False,bpop,fpop,count

if __name__ == "__main__":
    ibpop = raw_input("Please enter the starting bunny population ==> ")
    print ibpop
    ifpop = raw_input("Please enter the starting fox population ==> ")
    print ifpop
    info = check_convergence(ibpop,ifpop)
    print '(Bunny, Fox): Start (%d, %d)'%(int(ibpop),int(ifpop)),'End: (%d, %d),'%(info[1],info[2]),'Converged:',info[0],'in',info[3],'generations'