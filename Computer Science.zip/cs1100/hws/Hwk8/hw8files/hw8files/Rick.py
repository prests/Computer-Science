from Board import *
import math as m

class Rick(object):
##Constructor
    def __init__(self, boardname, x0, y0, length, dx, dy, dimension, alive=True):
        self.boardname = boardname
        self.x0 = int(x0)
        self.y0 = int(y0)
        self.length = int(length)
        self.dx = int(dx)
        self.dy = int(dy)
        self.dimension = boardname
        self.alive = alive
        
##Acessor Methods   
    def get_boardname(self):
        return self.boardname
    def get_x0(self):
        return self.x0
    def get_y0(self):
        return self.y0
    def get_length(self):
        return self.length
    def get_dx(self):
        return self.dx
    def get_dy(self):
        return self.dy
    def get_dimension(self):
        return self.dimension
    def get_alive(self):
        return self.alive
    
##Genereic print format
    def string(self, board):
        print 'Rick of %s is in %s at (%d,%d) with speed (%.1f,%.1f)'%(self.boardname, self.dimension, self.x0, self.y0, self.dx/board.get_gravity(), self.dy/board.get_gravity())
    
##If Rick hits an object
    def object_hit(self, board, time):
        self.dx = self.dx*-.5
        self.dy = self.dy*-1
        print 'Time %d: Rick of %s crashed into object at (%d,%d) in %s board New speed is(%.1f,%.1f)'%(time, self.boardname, self.x0, self.y0, self.dimension, self.dx/board.get_gravity(), self.dy/board.get_gravity())
    
##Move function
    def move(self, board):
        if(self.alive == True):
            self.x0 += int(self.dx/board.get_gravity())
            self.y0 += int(self.dy/board.get_gravity())
            
##Checks if on edge
    def check_edges(self, board, board_info, time):
        if(self.x0<=0):
            temp_dimension = self.dimension
            temp_x0 = self.x0
            temp_y0 = self.y0
            self.dimension = board.get_left_edge()
            self.x0 = board_info[self.dimension].get_portalx()
            self.y0 = board_info[self.dimension].get_portaly()
            print 'Time %d: Rick of %s moved from %s board to %s board'%(time, self.boardname, temp_dimension, self.dimension)
            print '\tPast location: Rick of %s is in %s board at (%d,%d) with speed (%.1f,%.1f)'%(self.boardname, temp_dimension, temp_x0, temp_y0, self.dx/float(board_info[temp_dimension].get_gravity()), self.dy/float(board_info[temp_dimension].get_gravity()))
            print '\tCurrent location: Rick of %s is in %s board at (%d,%d) with speed (%.1f,%.1f)'%(self.boardname, self.dimension, self.x0, self.y0, self.dx/float(board_info[self.dimension].get_gravity()), self.dy/float(board_info[self.dimension].get_gravity()))
        elif(self.x0>=1000 or self.x0+self.length-1>=1000):
            temp_dimension = self.dimension
            temp_x0 = self.x0
            temp_y0 = self.y0
            self.dimension = board.get_right_edge()
            self.x0 = board_info[self.dimension].get_portalx()
            self.y0 = board_info[self.dimension].get_portaly()
            print 'Time %d: Rick of %s moved from %s board to %s board'%(time, self.boardname, temp_dimension, self.dimension)
            print '\tPast location: Rick of %s is in %s board at (%d,%d) with speed (%.1f,%.1f)'%(self.boardname, temp_dimension, temp_x0, temp_y0, self.dx/float(board_info[temp_dimension].get_gravity()), self.dy/float(board_info[temp_dimension].get_gravity()))
            print '\tCurrent location: Rick of %s is in %s board at (%d,%d) with speed (%.1f,%.1f)'%(self.boardname, self.dimension, self.x0, self.y0, self.dx/float(board_info[self.dimension].get_gravity()), self.dy/float(board_info[self.dimension].get_gravity()))
        elif(self.y0<=0):
            temp_dimension = self.dimension
            temp_x0 = self.x0
            temp_y0 = self.y0
            self.dimension = board.get_down_edge()
            self.x0 = board_info[self.dimension].get_portalx()
            self.y0 = board_info[self.dimension].get_portaly()
            print 'Time %d: Rick of %s moved from %s board to %s board'%(time, self.boardname, temp_dimension, self.dimension)
            print '\tPast location: Rick of %s is in %s board at (%d,%d) with speed (%.1f,%.1f)'%(self.boardname, temp_dimension, temp_x0, temp_y0, self.dx/float(board_info[temp_dimension].get_gravity()), self.dy/float(board_info[temp_dimension].get_gravity()))
            print '\tCurrent location: Rick of %s is in %s board at (%d,%d) with speed (%.1f,%.1f)'%(self.boardname, self.dimension, self.x0, self.y0, self.dx/float(board_info[self.dimension].get_gravity()), self.dy/float(board_info[self.dimension].get_gravity()))
        elif(self.y0>=1000 or self.y0+self.length-1>=1000):
            temp_dimension = self.dimension
            temp_x0 = self.x0
            temp_y0 = self.y0
            self.dimension = board.get_up_edge()
            self.x0 = board_info[self.dimension].get_portalx()
            self.y0 = board_info[self.dimension].get_portaly()
            print 'Time %d: Rick of %s moved from %s board to %s board'%(time, self.boardname, temp_dimension, self.dimension)
            print '\tPast location: Rick of %s is in %s board at (%d,%d) with speed (%.1f,%.1f)'%(self.boardname, temp_dimension, temp_x0, temp_y0, self.dx/float(board_info[temp_dimension].get_gravity()), self.dy/float(board_info[temp_dimension].get_gravity()))
            print '\tCurrent location: Rick of %s is in %s board at (%d,%d) with speed (%.1f,%.1f)'%(self.boardname, self.dimension, self.x0, self.y0, self.dx/float(board_info[self.dimension].get_gravity()), self.dy/float(board_info[self.dimension].get_gravity()))
            
##Check if Rick is on another Rick
    def check_ricks(self, other_rick, board_info, time):
        for i in range(self.x0, self.x0+self.length):
            for j in range(other_rick.get_x0(), other_rick.get_x0()+other_rick.get_length()):
                if(i==j):
                    for i in range(self.y0, self.y0+self.length):
                        for j in range(other_rick.y0, other_rick.y0+self.length):
                            if(i==j):
                                return True
        return False
    
##Resets a Rick
    def reset_rick(self, board_info):
        temp_dimension = self.dimension
        self.dimension = self.boardname
        self.x0 = board_info[self.dimension].get_portalx()
        self.y0 = board_info[self.dimension].get_portaly()
        self.dx = self.dx/2
        self.dy = self.dy/2
        print '\t Rick of %s is in %s board at (%d,%d) with speed (%d,%d)'%(self.boardname, self.dimension, self.x0, self.y0, self.dx/board_info[self.dimension].get_gravity(), self.dy/board_info[self.dimension].get_gravity())
        
##Checks if a Rick is going fast enough
    def is_fast_enough(self):
        if(m.sqrt(self.dx**2+self.dy**2) <= 2*self.length and self.alive == True):
            return False
        
##Kills a Rick    
    def kill_rick(self, time):
        magnitude = m.sqrt(self.dx**2+self.dy**2)
        print 'Time %d: Rick of %s in %s board location (%d,%d) with speed magnitude %.1f stops.'%(time, self.boardname, self.dimension, self.dx, self.dy, magnitude)
        self.alive = False
        self.dx = 0
        self.dy = 0
        self.x0 = None
        self.y0 = None       