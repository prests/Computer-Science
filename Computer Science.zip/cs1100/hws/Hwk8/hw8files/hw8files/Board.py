class Board(object):
##Constructor
    def __init__(self,char,gravity,portalx,portaly,right_edge,up_edge,left_edge,down_edge,obstacles=[]):
        self.char = char
        self.gravity = int(gravity)
        self.portalx = int(portalx)
        self.portaly = int(portaly)
        self.right_edge = right_edge
        self.up_edge = up_edge
        self.left_edge = left_edge
        self.down_edge = down_edge
        self.obstacles = obstacles
        
##Acessor Methods
    def get_char(self):
        return self.char
    def get_gravity(self):
        return self.gravity
    def get_portalx(self):
        return self.portalx
    def get_portaly(self):
        return self.portaly
    def get_right_edge(self):
        return self.right_edge
    def get_up_edge(self):
        return self.up_edge
    def get_left_edge(self):
        return self.left_edge
    def get_down_edge(self):
        return self.down_edge
    def get_obstacles(self):
        return self.obstacles
    
##Generic print function
    def __str__(self):
        str1 = 'Board %s: Portal location: (%d,%d), Gravity: %d'%(self.char,self.portalx,self.portaly,self.gravity)
        obst_str = ''
        for i in range(0,len(self.obstacles)):
            if(i==len(self.obstacles)-1):
                obst_str += str(self.obstacles[i])
            else:
                obst_str += str(self.obstacles[i])+', '
        str2 = '\tObstacles at: [%s]'%obst_str
        str3 = '\tPortals to: right: '+self.right_edge+', up: '+self.up_edge+', left: '+self.left_edge+', down: '+self.down_edge
        return str1+'\n'+str2+'\n'+str3