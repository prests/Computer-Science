import math as m
from Board import *
from Rick import *

##Creates a dictionary of boards from file
def board_seperator(board_info):
    boards = {}
    for line in board_info:
        obstacles = []
        i = 8
        line = line.strip().split('|')
        while i < len(line):
            obstacles.append((int(line[i]), int(line[i+1])))
            i += 2
        boards[line[0]] = Board(line[0],int(line[1]),int(line[2]),int(line[3]),line[4],line[5],line[6],line[7],obstacles)
    return boards
##Creates a dictionary of ricks from files       
def rick_seperator(rick_info):
    ricks = {}
    for line in rick_info:
        line = line.strip().split('|')
        ricks[line[0]] = Rick(line[0],int(line[1]),int(line[2]),int(line[3]),int(line[4]),int(line[5]),line[0])
    return ricks
            
        
##Main
if __name__ == '__main__':
    time = 0
    board_name = raw_input('Board file name => ')#Board input
    print board_name
    board_info = board_seperator(open(board_name))
    rick_name = raw_input('Rick file name => ')#Rick input
    print rick_name
    
    rick_info = rick_seperator(open(rick_name))
    for i in board_info:
        print str(board_info[i])
    
    print 'All Ricks'
    for i in rick_info:
        print 'Time %d:'%time,rick_info[i].string(board_info[rick_info[i].get_dimension()])#initial ricks
    print '-'*75
    print 
    while(time<100):#Simulation
        time+=1
        for i in rick_info:
            rick_info[i].move(board_info[rick_info[i].get_dimension()])
        for i in rick_info:#Goes through each Rick at time
            encounter = False
            for j in board_info[rick_info[i].get_dimension()].get_obstacles():#Checks if a rick hit an obstacle when it moved
                if(rick_info[i].get_alive() == True and j[0]>=rick_info[i].get_x0() and j[0]<=rick_info[i].get_x0()+rick_info[i].get_length()-1 and j[1]>=rick_info[i].get_y0() and j[0]<=rick_info[i].get_y0()+rick_info[i].get_length()-1):
                    rick_info[i].object_hit(board_info[rick_info[i].get_dimension()], time)
            if(rick_info[i].get_alive() == True):
                rick_info[i].check_edges(board_info[rick_info[i].get_dimension()], board_info, time)#Checks if Rick is on or over an edge
            for j in rick_info:#Checks if a Rick is on another Rick
                if(rick_info[i].get_alive() == True and rick_info[j].get_alive() == True and i!=j and rick_info[i].check_ricks(rick_info[j], board_info, time)==True):
                    print 'Time %d: Rick of %s and Rick of %s have collided in %s board.'%(time, rick_info[i].get_boardname(), rick_info[j].get_boardname(), rick_info[i].get_dimension())
                    rick_info[i].reset_rick(board_info)
                    rick_info[j].reset_rick(board_info)
            if(rick_info[i].is_fast_enough() == False and rick_info[i].get_alive() == True):
                rick_info[i].kill_rick(time)
        if(time%10 == 9):
            print
            print '-'*75
            print 'End of time %d: all free Ricks'%time
            for i in rick_info:
                if(rick_info[i].get_alive()==True):
                    rick_info[i].string(board_info[rick_info[i].get_dimension()])
            print '-'*75
            print
    print
    print '-'*75
    
    print 'Time %d: Simulation ended'%time
    print
    
    print 'The following Ricks are still alive:'
    for i in rick_info:
        if(rick_info[i].get_alive()==True):
            print '   Rick of %s is in %s universe at location (%d,%d)'%(rick_info[i].get_boardname(), rick_info[i].get_dimension(), rick_info[i].get_x0(), rick_info[i].get_y0())
    print
    
    counter = 0
    for i in rick_info:
        if(rick_info[i].get_alive()==False):
            counter +=1
    if(counter>0):
        print "The following Rick's were caught by Transdimensional Council of Ricks:"
        for i in rick_info:
            if(rick_info[i].get_alive()==False):
                print '   Rick of %s'%rick_info[i].get_boardname()
    else:
        print 'No Ricks were caught by Tansdimensional Council of Ricks'
    print '-'*75