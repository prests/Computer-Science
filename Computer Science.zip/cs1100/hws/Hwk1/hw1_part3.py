def NamePopularity():
    name = raw_input('Please enter a name ==> ')
    print name
    count70 = raw_input('Count in 1970 => ')
    print count70
    count80 = raw_input('Count in 1980 => ')
    print count80
    count90 = raw_input('Count in 1990 => ')
    print count90
    count2000 = raw_input('Count in 2000 => ')
    print count2000
    count70f=float(count70);
    count80f=float(count80);
    count90f=float(count90);
    count2000f=float(count2000);
    
    
    string = '\nBabies named '+name
    print string + "\n" + "*"*(len(string)-1);
    print ''
    print 'Year / Total / % change from previous decade'
    print '1970 /',str(count70)
    change1 = (count80f-count70f)/count70f*100
    strchange1 = "%.2f"%change1
    print '1980 /', count80,"/ %", strchange1
    change2 = (count90f-count80f)/count80f*100
    strchange2 = "%.2f"%change2
    print '1990 /', count90,"/ %", strchange2
    change3 = (count2000f-count90f)/count90f*100
    strchange3 = "%.2f"%change3
    print '2000 /', count2000,"/ %", strchange3
    average = (change1+change2+change3)/3
    straverage = "%.2f"%average
    print "Average change: %", straverage
    
    
NamePopularity()