def draw():
    temp = True
    while(temp==True):
        Width=raw_input('Width of box ==> ') 
        print Width
        Height=raw_input('Height of box ==> ')
        print Height
        Character=raw_input('Enter frame character ==> ')
        print Character
        try:
            int(float(Height))
            int(float(Width))
            temp=False
        except:
            print 'width or height is not an integer'
    temp = 0
    label= Width+'x'+Height
    labelsize = len(label)
    print ''
    print 'Box:'
    while(temp<int(Height)):
        if temp==0 or temp==int(Height)-1:
            print Character*int(Width)
        else:
            print Character, " "*(int(Width)-4), Character            
        if temp==0:    
            print str(Character+" "+label+" "*(int(Width)-(3+labelsize))+Character)
            temp= temp+1
        temp= temp+1

draw()