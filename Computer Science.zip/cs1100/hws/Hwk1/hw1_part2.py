def madlib():
    propername = raw_input('proper name ==> ')
    print propername
    emotion = raw_input('emotion ==> ')
    print emotion
    verb = raw_input('verb ==> ')
    print verb
    adjective1 = raw_input('adjective ==> ')
    print adjective1
    noun1 = raw_input('noun ==> ')
    print noun1
    adjective2 = raw_input('adjective ==> ')
    print adjective2
    noun2 = raw_input('noun ==> ')
    print noun2
    adjective3 = raw_input('adjective ==> ')
    print adjective3
    print ''
    print 'Here is your output:'
    print 'Look,',propername,'...'
    print " I can see you're really",emotion,'about this ...'
    print ' I honestly think you ought to',verb,'calmly ...'
    print ' take a',adjective1,noun1,'and think things over ...'
    print " I know I've made some very",adjective2,'decisions recently,'
    print ' but I can give you my complete',noun2,'that my work will be back'
    print str(' to '+adjective3+'.')

madlib()