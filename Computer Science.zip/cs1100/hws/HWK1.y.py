def draw():
    temp = True
    while(temp==True):
        Width=raw_input('Width of Box ==> ') 
        Height=raw_input('Height of Box ==> ')
        Character=raw_input('Enter frame of Character ==> ')
        try:
            int(float(Height))
            int(float(Width))
            temp=False
        except:
            print 'width or height is not an integer'
    temp = 0
    label= Width+'x'+Height
    labelsize = len(label)
    print ''
    print 'Box:'
    while(temp<int(Height)):
        if temp==0 or temp==int(Height)-1:
            print Character*int(Width)
        else:
            print Character, " "*(int(Width)-4), Character            
        if temp==0:    
            print str(Character+" "+label+" "*(int(Width)-(3+labelsize))+Character)
            temp= temp+1
        temp= temp+1

draw()

def madlib():
    propername = raw_input('proper name ==> ')
    emotion = raw_input('emotion ==> ')
    verb = raw_input('verb ==> ')
    adjective1 = raw_input('adjective ==> ')
    noun1 = raw_input('noun ==> ')
    adjective2 = raw_input('adjective ==> ')
    noun2 = raw_input('noun ==> ')
    adjective3 = raw_input('adjective ==> ')
    print ''
    print 'Here is your output:'
    print 'Look,',propername,'...'
    print "I can see you're really",emotion,'about this ...'
    print 'I honestly think you ought to',verb,'calmly ...'
    print 'take a',adjective1,noun1,'and think things over ...'
    print "I know I've made some very",adjective2,'decisions recently,'
    print 'but I can give you my complete',noun2,'that my work will be back'
    print 'to',adjective3

madlib()

def NamePopularity():
    name = raw_input('Please enter a name ==> ')
    count70 = raw_input('Count in 1970 ==> ')
    count80 = raw_input('Count in 1980 ==> ')
    count90 = raw_input('Count in 1990 ==> ')
    count2000 = raw_input('Count in 2000 ==> ')
    count70=float(count70);
    count80=float(count80);
    count90=float(count90);
    count2000=float(count2000);
    
    
    string = '\nBabies named '+name
    print string + "\n" + "*"*(len(string)-1);
    print 'Year / Total/ % change from previous decade'
    print str('1970 /'+str(count70))
    change1 = (count80-count70)/count70*100
    print str('1980 /'+str(count80)+'/ %' + str(change1))
    change2 = (count90-count80)/count80*100
    print str('1990 /'+str(count90)+'/ %' +str(change2))
    change3 = (count2000-count90)/count90*100
    print str('2000 /'+str(count2000)+'/ %'+str(change3))
    average = (change1+change2+change3)/3
    print str('Average change: %'+ str(average))
    
    
NamePopularity()