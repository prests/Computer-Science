"""Author: Shayne Preston prests@rpi.edu

   Purpose: This program reads a word from user input and prints whether
   the word is at least 8 characters long, starts with a vowel, 
   alternates vowels and consonants and the consonants are in 
   increasing alphabetical order.

"""

######### Put all your function definitions here
######### I am putting in a template to get you started

def is_alternating(word):
    wordstr = str("'"+word+"'")
    wordtup = tuple(word)
    vowels = 'aeiou'
    vowels = tuple(vowels)
    consonants = 'bcdfghjklmnpqrstvwxyz'
    consonants = tuple(consonants)    
    if(len(word)>=8):
        for i in range(0,(len(word)-1)):
            if(i==0):
                for k in range(0,(len(vowels)-1)):
                    if(wordtup[0]==vowels[k]):
                        vowelinfo= [k,vowels[k]]
                    elif(wordtup[0]!=vowels[k] and k==(len(vowels)-1)):
                        print "The word",wordstr,"is not alternating"
                        return False
            else:
                if(i%2==1):
                    for k in range(0,(len(consonants)-1)):
                        if(wordtup[i]==consonants[k]):
                            if(i==1):
                                consonentinfo= [k,consonants[k]]
                            else:
                                if(k>consonentinfo[0]):
                                    consonentinfo= [k,consonants[k]]
                                else:
                                    print "The word",wordstr,"is not alternating"
                                    return False
                        elif(wordtup[i]!=consonants[k] and k==(len(consonants)-1)):
                            print "The word",wordstr,"is not alternating"
                            return False
                else:
                    for k in range(0,(len(vowels)-1)):
                        if(wordtup[i]==vowels[k]):
                            vowelinfo= [k,vowels[k]]
                        elif(wordtup[i]!=vowels[k] and k==(len(vowels)-1)):
                            print "The word", wordstr, "is not alternating"
                            return False
        print "The word",wordstr,"is alternating"
        return True
    else:
        print "The word",wordstr,"is not alternating"
        return False


######## This is the main body of your program
######## All code should be below the if statement

######## This if statement is executed when we run the program
######## but not when we import it as a module

#######  Keep the body of your program small, put main
#######  functions in a function, but each function should do
#######  something simple

if __name__ == "__main__":
    word = raw_input("Enter a word => ")
    print word

    ## now call your function here and check its output
    
    word= word.lower()
    is_alternating(word)