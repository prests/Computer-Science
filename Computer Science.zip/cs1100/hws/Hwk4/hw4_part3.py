"""Author: Shayne Preston prests@rpi.edu

   Purpose: This program takes in two countries from user input and prints plus if the value is over the cutoff which is calculated using a formula below. Plus represented if the value of the tuple at i was greater than or equal to, while minus meant it was less than the tuple value at i. it also printed a month marker above it with the name of the country beside it's plus/minus line

"""
import hw4_util

def cut_off(cdata):
    if(len(cdata)==0):
        return False
    else:
        cutoff = ((sum(cdata)/52)+max(cdata))/2
        return cutoff
    
def drawout(cdata,cutoff,country):
    drawn = str(country).ljust(12)
    for i in range(0,len(cdata)):
        if(int(cdata[i])>=cutoff):
            drawn = str(drawn+'+')
        else:
            drawn = str(drawn+'-')
    print drawn

def title_maker():
    title = ''
    for i in range(1,13):
        title = title+str(i).ljust(4)
    print ' '*11,title
    
country1 = raw_input('First country => ')
print country1
country2 = raw_input('Second country => ')
print country2

cdata1 = hw4_util.read_flu(country1)
cdata2 = hw4_util.read_flu(country2)
cutoff1 = cut_off(cdata1)
cutoff2 = cut_off(cdata2)

if(cutoff1 == False):
    print 'I could not find country',country1
if(cutoff2 == False or cutoff1 == False):
    print 'I could not find country',country2
elif(cutoff1>-1 and cutoff2>-1):
    title_maker()
    drawout(cdata1,cutoff1,country1)
    drawout(cdata2,cutoff2,country2)