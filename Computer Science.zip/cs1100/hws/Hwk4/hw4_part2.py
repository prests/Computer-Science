import hw4_util 

"""Author: Shayne Preston prests@rpi.edu

   Purpose: this program takes in a  preexistinglist of lego dimensions and then takes in a lego dimension and an amount.
   Using the area of the legos that are in the lego list and the area of the legos inputed and amount you can find which lego type would be
   most optimal. Then checking if you have the number of legos require you print the lego and amount of lego used. Lastly print out the legos remaining.

"""

def find_legos(kind,amount,legos):
    legoarea = int(float(kind[0]))*int(float(kind[2]))*int(float(amount))
    for i in range(len(legos)-1,-1,-1):
        iarea=(float(legos[i][0])*float(legos[i][2]))
        finalarea=legoarea/iarea
        if(finalarea%1==0 and legos.count(legos[i])>=finalarea and legoarea == iarea*finalarea):
            final = [legos[i],int(finalarea)]
            for k in range(0,int(finalarea)):
                legos.pop(legos.index(legos[i-k]))   
            final.append(legos)
            return  final 
        
    return 'none'
        
legos = hw4_util.read_legos()
print "Current legos",legos    
legotype = raw_input("Type of lego wanted => ")
print legotype
legoamount = raw_input("Quantity wanted => ")
print legoamount



final = find_legos(legotype,legoamount,legos)
if(final == 'none'):
    print "I don't have",int(float(legoamount)),legotype,"legos"
else:
    print "I can use", final[1],final[0],"legos for this"
    print "Remaining legos",final[2]