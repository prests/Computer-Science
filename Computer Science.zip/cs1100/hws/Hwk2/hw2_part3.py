def reverse(number):
    hundreds = int(number)%10*100
    ten = int(number)%100-int(number)%10
    single = (int(number)-int(number)%100)/100
    reversed_num = hundreds+ten+single
    return reversed_num

num1= raw_input('Enter a value ==> ')
print num1
print ''
print 'Here is the computation:'
num2 = reverse(num1)
if(int(num1)<int(num2)):
    sum1 = int(num2) - int(num1)
    print num2,'-',num1,'=',sum1
else:
    sum1 = int(num1) - int(num2)
    print num1,'-',num2,'=',sum1
num3 = reverse(sum1)
sum2 = int(sum1) + int(num3)
print sum1,'+',num3,'=',sum2
if(sum2==1089):
    print 'You see, I told you.'
else:
    print 'Are you sure your input is valid?'
