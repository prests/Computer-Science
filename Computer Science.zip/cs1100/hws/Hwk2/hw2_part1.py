import math

def volume_prism(length,width,height):
    volume = length*width*height
    return volume

def find_length(radius,volume):
    cyl_height = volume/(math.pi*radius**2)
    return cyl_height

length = raw_input('Length of rectangular prism (m) ==> ')
print length
width = raw_input('Width of rectangular prism (m) ==> ')
print width
height = raw_input('Height of rectangular prism (m) ==> ')
print height

length = float(length)
width = float(width)
height = float(height)

total_water = 3*30*70*volume_prism(length,width,height)

print str('Water needed for ('+str(length)+'m,'+str(width)+'m,'+str(height)+'m) locks is '+ str(total_water)+ 'm^3.')

radius = raw_input('Radius of cylinder (m) ==> ')
print radius
radius = float(radius)

cyl_height = find_length(radius,total_water)

print str('Lake with radius '+str(radius)+'m will lose %.1f'%cyl_height+'m depth in three months.')