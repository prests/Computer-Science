"""Author: <Justin Palovchak palovj@rpi.edu>
   Purpose: This program reads a certain month from the user and prints a certain set of information
"""
import json
def compute(month, month_data):
    stats = {}
    keycnt = 0
    for key in month_data[0]:
        if key != 'year':
            if key == "EMXT" or key == "EMNT" or key == "DT90" or key == "DX32" \
               or key == "TPCP" or key == "TSNW" or key == "MNTM":
                stats[key] = list()
                for i in range(len(month_data)): 
                    if month_data[i][key] != 0 and month_data[i][key] != -9999:
                        if key == "MNTM":
                            stats[key].append((month_data[i]['year'], month_data[i][key]))
                        else:
                            stats[key].append((month_data[i][key], month_data[i]['year']))
                    stats[key].sort()               
        keycnt += 1
    stats
    return stats
def printstrs(data, key):
    end = ''
    for i in data[key]:
        end += "%d: %.1f, " %(i[0], i[1])
    if len(data[key]) == 0:
        return"Not enough data"
    return end.strip(", ")
    
def histo(avg):
    for i in range(len(avg) - 2):
        print "%d-%d: " %(avg[i][0], avg[i][1]) + '*' * int(avg[i][2])
    
if __name__ == '__main__':
    data = json.loads(open("tempdata.json").read())
    
    user_month = int(raw_input("Enter a month (1-12) => "))
    print user_month
    
    month_data = []
    for i in range(len(data)):
        if user_month == data[i]['month']:
            month_data.append(data[i])
      
    stats = compute(user_month, month_data)
    
    border = 50 *'-'
    
    print_list = {}
    for key in stats:
        if key == "EMNT":
            print_list[key] = list()
            for i in range(3):
                print_list[key].append((stats[key][i][1], stats[key][i][0]))
        elif key == "EMXT" or key == "DT90" or key == "DX32":
            print_list[key] = list()
            if len(stats[key]) > 2:
                for i in range(-1, -4, -1):
                    print_list[key].append((stats[key][i][1], stats[key][i][0]))
        elif key == "TPCP" or key == "TSNW":
            key1 = key + "low"
            key2 = key + "high"
            print_list[key1] = list()
            print_list[key2] = list()
            if len(stats[key]) > 2:
                for i in range(3):
                    print_list[key1].append((stats[key][i][1], stats[key][i][0]))
                for i in range(-1, -4, -1):
                    print_list[key2].append((stats[key][i][1], stats[key][i][0]))            
        else:
            i = 0
            avgs = []
            while i < len(stats[key]): ##histogram data
                tot = 0
                for j in range(min(10, (len(stats[key]) - i))):
                    tot += stats[key][j+i][1]
                avgs.append((stats[key][i][0], stats[key][min((9 + i), (len(stats[key]) - 1))][0] ,(tot/min(10, (len(stats[key]) - i)))))
                i += 10
            tot = 0
            for i in range(len(stats[key])): ##overall
                tot += stats[key][i][1]
            avgs.append(tot/float(len(stats[key])))
            tot = 0
            for i in range(-1,-11,-1): ##last 10 years
                tot += stats[key][i][1]
            avgs.append(tot/10.)                
    
    print "Temperatures\n" + border + "\nHighest max  value =>", printstrs(print_list, "EMXT")\
          + "\nLowest min value =>", printstrs(print_list, "EMNT") + "\nHighest days with max "\
          ">= 90 =>", printstrs(print_list, "DT90") + "\nHighest days with max <= 32 =>", \
          printstrs(print_list, "DX32") + "\n\nPrecipitation\n" + border + "\nHighest total =>",\
          printstrs(print_list, "TPCPhigh") + "\nLowest total =>", printstrs(print_list, "TPCPlow")\
          + "\nHighest snow depth =>", printstrs(print_list, "TSNWhigh") + "\nLowest snow depth =>",\
          printstrs(print_list, "TSNWlow") + "\n\nAverage temperatures\n" + border + "\nOverall: %.1f"\
          "\nFirst 10 years: %.1f\nLast 10 years: %.1f\n" %(avgs[-2], avgs[0][2] , avgs[-1]) 
    histo(avgs)