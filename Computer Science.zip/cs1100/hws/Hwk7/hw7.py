import json
import operator
import collections

def data_finder(month,info):
    data = json.loads(open('tempdata.json').read())
    needed_data = {}
    for i in range(len(data)):
        if(data[i]['month'])==month:
            if(data[i][info]!=0 and data[i][info] != -9999):
                needed_data[data[i]['year']] = data[i][info]
    return needed_data

def dict_to_list(data):
    lists = []
    for i in data:
        lists.append((i, data[i]))
    return lists

def hect_print(info):
    string = str(info[0])+'-'+str(info[1])+': '+'*'*(int(info[2]))
    return string

def averager(data):
    if(len(data)==0):
        return 'Not enough data'
    String = 0
    for i in data:
        String += data[i]
    String = str('%.1f'%(String/len(data)))
    return String

def first_last(data):
    if(len(data)==0):
        return 'Not enough data'
    String = 0
    counter = 0
    for i in data:
        if(counter == 10):
            break
        String += data[i]
        counter+=1
    String = str('%.1f'%(String/10))
    return String

def print_3(data):
    if(len(data)==0):
        return 'Not enough data'
    count = 0
    String = ""
    for i in data:
        if(count ==3):
            break
        if(count ==2):
            String += str(i[0])+': '+str('%.1f'%float(i[1]))
        else:
            String += str(i[0])+': '+str('%.1f'%float(i[1]))+', '
        count+=1
    return String
            
if __name__ == '__main__':
    data = json.loads(open('tempdata.json').read())
    month = int(raw_input("Enter a month (1-12) => "))
    print month
    temperatureshigh = data_finder(month,'EMXT')
    temperatureshigh = sorted(temperatureshigh.items(), key=lambda x: (x[1],x[0]), reverse = True)
    temperatureslow = data_finder(month,'EMNT')
    temperatureslow = sorted(temperatureslow.items(), key= operator.itemgetter(1))
    highabove90 = data_finder(month,'DT90')
    highabove90 = sorted(highabove90.items(), key=lambda x: (x[1],x[0]), reverse = True)
    highbelow32 = data_finder(month,'DX32')
    highbelow32 = sorted(highbelow32.items(), key=lambda x: (x[1],x[0]), reverse = True)
    print "Temperatures\n","-"*50
    print 'Highest max  value =>', print_3(temperatureshigh)
    print 'Lowest min value =>', print_3(temperatureslow)
    print 'Highest days with max >= 90 =>', print_3(highabove90)
    print 'Highest days with max <= 32 =>', print_3(highbelow32)
    print
    Highesttotal = data_finder(month,'TPCP')
    lowesttotal = Highesttotal
    Highesttotal = sorted(Highesttotal.items(), key=lambda x: (x[1],x[0]), reverse = True)
    lowesttotal = sorted(lowesttotal.items(), key= operator.itemgetter(1))
    Highestsnow = data_finder(month,'TSNW')
    lowestsnow = Highestsnow
    Highestsnow = sorted(Highestsnow.items(), key=lambda x: (x[1],x[0]), reverse = True)
    Lowestsnow = sorted(lowestsnow.items(), key= operator.itemgetter(1))
    print "Precipitation\n","-"*50
    print "Highest total =>", print_3(Highesttotal)
    print "Lowest total =>", print_3(lowesttotal)
    print "Highest snow depth =>", print_3(Highestsnow)
    print "Lowest snow depth =>", print_3(Lowestsnow)
    print
    Overall = data_finder(month,'MNTM')
    First_10_years = collections.OrderedDict(sorted(Overall.items()))
    Last_10_years = collections.OrderedDict(sorted(Overall.items(), reverse = True))
    print "Average temperatures\n","-"*50
    print "Overall:",averager(Overall)
    print "First 10 years:",first_last(First_10_years)
    print "Last 10 years:",first_last(Last_10_years)
    print
    
    lists = dict_to_list(First_10_years)
    graph_info = []
    i=0
    while i<len(lists):
        sumations = 0
        for j in range(min(10,len(lists)-i)):
            sumations += float(lists[j+i][1])
        graph_info.append((lists[i][0],lists[min((9+i),(len(lists))-1)][0],(sumations/min(10,(len(lists)-i)))))
        i += 10
    for i in graph_info:
        print hect_print(i)