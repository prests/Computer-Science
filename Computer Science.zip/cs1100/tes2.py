Python 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license" for more information.
>>> def encode(word):
    word=word.replace(' a','rxr')
    word=word.replace('he','vw')
    word=word.replace('e','az az')
    word=word.replace('y','eie')
    word=word.replace('u','yyy')
    word=word.replace('an','uq')
    word=word.replace('th','aige')
    word=word.replace('o','tzzt')
    return word

def decode(word):
    word=word.replace('tzzt','o')
    word=word.replace('aige','th')
    word=word.replace('uq','an')
    word=word.replace('yyy','u')
    word=word.replace('eie','y')
    word=word.replace('az az','e')
    word=word.replace('vw','he')
    word=word.replace('rxr',' a')
    return word

decode_word = raw_input("Enter cipher text ==> ")
print decode_word

decode_word = str(decode_word)

print ''
print "Deciphered as ==>", decode(decode_word)
print "Difference in length ==>",len(decode_word)-len(decode(decode_word))

encode_word = raw_input("\nEnter regular text ==> ")

print encode_word
print ''
print "Encrypted as ==>",encode(encode_word)
print "Difference in length ==>",len(encode(encode_word))-len(encode_word)
