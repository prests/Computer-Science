if __name__ == "__main__":
    nummovies = []
    f = open("hanks.txt")