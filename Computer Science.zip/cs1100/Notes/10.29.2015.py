def parse_line(line):
    m = line.strip().split("|")
    actor = m[0].strip()
    movie = m[1].strip()
    year = int(m[2])
    return actor, movie, year

def find_actor(nummovies, a):
    for i in range(len(nummovies)):
        if nummovies[i][0] == a:
            return i
    nummovies.append ( [a, 0] )
    return len(nummovies)-1

if __name__ == "__main__":
    nummovies = []
    
    ##open the file
    f = open("hanks.txt")
    
    ##read line by line
    for line in f:
        
        a,m,y = parse_line(line)
        
        ## find actor index
        idx = find_actor(nummovies, a)
        
        ## add 1 for movies
        nummovies[idx][1] += 1