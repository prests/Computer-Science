import lab06_util as util
"""
bd = [ [ '1', '.', '.', '.', '2', '.', '.', '3', '7'],
       [ '.', '6', '.', '.', '.', '5', '1', '4', '.'],
       [ '.', '5', '.', '.', '.', '.', '.', '2', '9'],
       [ '.', '.', '.', '9', '.', '.', '4', '.', '.'],
       [ '.', '.', '4', '1', '.', '3', '7', '.', '.'],
       [ '.', '.', '1', '.', '.', '4', '.', '.', '.'],
       [ '4', '3', '.', '.', '.', '.', '.', '1', '.'],
       [ '.', '1', '7', '5', '.', '.', '.', '8', '.'],
       [ '2', '8', '.', '.', '4', '.', '.', '.', '6'] ]
       
"""
#print len(bd)
#print len(bd[0])
#print bd[0][0]
#print bd[8][8]
def printBoard(board):
    for i in range(0,len(board)):
        if(i%3==0):
            print '-'*25
        str=''
        for j in range(0,len(board[0])):
            if(j%3==0):
                str+='| '
            str+= '%s '%(board[i][j])
        str+='|'
        print str
    print '-'*25
    
def numInThirds(row,col,num,board):
    tracker=[[],[],[]],[[],[],[]],[[],[],[]]
    first=-1
    for i in range(0,9):
        second=-1
        if(i%3==0):
            first+=1
        for j in range(0,9):
            if(j%3==0):
                second+=1
            tracker[first][second].append(board[i][j])
    return tracker[row/3][col/3].count(num)>0
        
    
    
def ok_to_add(row,col,num,board):
    for i in range(0,len(board)):
        if(board[i][col]==num or board[row][i]==num or numInThirds(row,col,num,board)):
            return False
    return True
def add(row,col,num,board):
    board[row][col]=num
def solved(board):
    for i in range(0,9):
        for j in range(0,9):
            temp=board[i][j]
            board[i][j]='0'
            if(board[i][j]=='.' or not ok_to_add(i,j,temp,board)):
                board[i][j]=temp
                return False
            else:
                board[i][j]=temp 
    return True
filename=raw_input("Enter file name: ")
bd=util.read_sudoku(filename)
printBoard(bd)
while(True): 
    if(solved(bd)):
        print "You Won"
        break 
    else:
        print "Not solved"
    
    row = raw_input("Enter row: ")
    while(not row.isdigit()):
        if(row=='print'):
            printBoard(bd)
        row = raw_input("Enter row: ")
    col = raw_input("Enter Col: ")
    while(not col.isdigit()):
        if(col=='print'):
            printBoard(bd)        
        col = raw_input("Enter Col: ")
       
    #temp=bd[int(float(row))][int(float(col))]    
    #bd[int(float(row))][int(float(col))]='#' 
    #printBoard(bd)
    
    number = raw_input("Enter the number: ") 
    while(not number.isdigit()):
        if(number=='print'):
            printBoard(bd)        
        number = raw_input("Enter the number: ") 
    
    if(ok_to_add(int(float(row)),int(float(col)),number,bd)):
        add(int(float(row)),int(float(col)),number,bd)
        printBoard(bd)
    else:
        #bd[int(float(row))][int(float(col))]=temp
        print "This number cannot be added"
        printBoard(bd)