bd = [ [ '1', '.', '.', '.', '2', '.', '.', '3', '7'],
       [ '.', '6', '.', '.', '.', '5', '1', '4', '.'],
       [ '.', '5', '.', '.', '.', '.', '.', '2', '9'],
       [ '.', '.', '.', '9', '.', '.', '4', '.', '.'],
       [ '.', '.', '4', '1', '.', '3', '7', '.', '.'],
       [ '.', '.', '1', '.', '.', '4', '.', '.', '.'],
       [ '4', '3', '.', '.', '.', '.', '.', '1', '.'],
       [ '.', '1', '7', '5', '.', '.', '.', '8', '.'],
       [ '2', '8', '.', '.', '4', '.', '.', '.', '6'] ]

print len(bd)
print len(bd[0])
print bd[0][0]
print bd[8][8]
def printPuzzle(bd):
    print '-'*25
    for i in range(0,len(bd)):
        string = '| '
        if(i==3 or i==6):
            print '-'*25
        for j in range(0,len(bd[i])):
            if(j==3 or j==6):
                string = string +'| '
            string = string + str(bd[i][j]) + ' '
        string = string + '|'
        print string
    print '-'*25
printPuzzle(bd)

def ok_to_add(number,row,column,bd):
    numbers = [1,2,3,4,5,6,7,8,9]
    for i in range(0,8):
        if(str(bd[row][column])==str(numbers[i])):
            print 'Cannot add'
            return False
    for i in range(0,9):
        if(int(number) == str(bd[int(row)][i])):
            print 'Cannot add'
            return False
    for i in range(0,9):
        if(str(number) == str(bd[i][int(column)])):
            print 'Cannot add'
            return False
    if(row<3):
        rowtemp=0
    elif(row<6):
        rowtemp=1
    elif(row<=8):
        rowtemp=2
    if(column<3):
        coltemp=0;
    elif(column<6):
        coltemp=1
    elif(column<=8):
        coltemp=2
    for i in range(0,3):
        for j in range(0,3):
            if(rowtemp==0 and columntemp==0):
                if(str(number)==str(bd[i][j])):
                    print 'Cannot add'
                    return False
            elif(rowtemp==0 and coltemp!=0):
                val1 = j + 3*int(coltemp)
                if(str(number)==str(bd[i][val1])):
                    print 'Cannot add'
                    return False
            elif(rowtemp!=0 and coltemp==0):
                val1 = i + 3*int(rowtemp)
                if(str(number)==str(bd[val1][j])):
                    print 'Cannot add'
                    return False
            else:
                val1 = i +3*int(rowtemp)
                val2 = j +3*int(coltemp)
                if(str(number)==str(bd[val1][val2])):
                    print 'Cannot add'
                    return False
    print 'Can add'
    return True
number = raw_input("Enter a number to add==> ")
number = int(number)
row = raw_input("Enter a row to add to==> ")
row = int(row)
column = raw_input("Enter a column to add to==> ")
column = int(column)
ok_to_add(number,row,column,bd)


