import lab06_util

filename = raw_input("Enter file name ==> ")
bd = lab06_util.read_sudoku(filename)

def printPuzzle(bd):
    print '-'*25
    for i in range(0,len(bd)):
        string = '| '
        if(i==3 or i==6):
            print '-'*25
        for j in range(0,len(bd[i])):
            if(j==3 or j==6):
                string = string +'| '
            string = string + str(bd[i][j]) + ' '
        string = string + '|'
        print string
    print '-'*25
printPuzzle(bd)

def ok_to_add(number,row,column,bd):
    for i in range(0,len(bd)):
        if(int(number) == str(bd[int(row)][i]) and i!=column):
            print 'Cannot add'
            return False
    for i in range(0,9):
        if(str(number) == str(bd[i][int(column)]) and i!=row):
            print 'Cannot add'
            return False
    if(row<3):
        rowtemp=0
    elif(row<6):
            rowtemp=1
    elif(row<=8):
        rowtemp=2
    if(column<3):
        coltemp=0;
    elif(column<6):
        coltemp=1
    elif(column<=8):
        coltemp=2
    for i in range(0,3):
        for j in range(0,3):
            if(rowtemp==0 and coltemp==0):
                if(str(number)==str(bd[i][j]) and i!=row and j!=column):
                    print 'Cannot add'
                    return False
            elif(rowtemp==0 and coltemp!=0):
                val1 = j + 3*int(coltemp)
                if(str(number)==str(bd[i][val1]) and i!=row and j!=column):
                    print 'Cannot add'
                    return False
            elif(rowtemp!=0 and coltemp==0):
                val1 = i + 3*int(rowtemp)
                if(str(number)==str(bd[val1][j]) and i!=row and j!=column):
                    print 'Cannot add'
                    return False
            else:
                val1 = i +3*int(rowtemp)
                val2 = j +3*int(coltemp)
                if(str(number)==str(bd[val1][val2]) and i!=row and j!=column):
                    print 'Cannot add'
                    return False
    print 'Can add'
    return True

def verifyboard(bd):
    for i in range(0,len(bd)):
        for j in range(0,len(bd)):
            if(str(bd[i][j])=='.'):
                return False
            elif(ok_to_add(bd[i][j],i,j,bd)==False):
                return False
    return True
def solved(board):
    for i in range(0,9):
        for j in range(0,9):
            temp=board[i][j]
            board[i][j]='0'
            if(board[i][j]=='.' or not ok_to_add(i,j,temp,board)):
                board[i][j]=temp
                return False
            else:
                board[i][j]=temp 
    return True
while(True):
    number = raw_input("Enter a number to add==> ")
    number = int(number)
    row = raw_input("Enter a row to add to==> ")
    row = int(row)
    column = raw_input("Enter a column to add to==> ")
    column = int(column)
    if(ok_to_add(number,row,column,bd)):
        checker = True
        numbers = [1,2,3,4,5,6,7,8,9]      
        for i in range(0,len(bd)):
            for j in range(0,len(bd)):
                for k in range(0,8):
                    if(str(bd[row][column])==str(numbers[k])):
                        if(ok_to_add(bd[i][j],i,j,bd)==False):
                            checker= False
                        else:
                            if(i==row and j==column):
                                if(ok_to_add(number,row,column,bd)==False):
                                    checker= False
        if(checker==True):
            bd[row][column]=number
            printPuzzle(bd)
        else:
            printPuzzle(bd)
    if(solved(bd)==True):
        break
print 'Solved!'
        
    


