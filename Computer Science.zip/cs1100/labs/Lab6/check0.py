def print0to8():
    string = ''
    for i in range(0,9):
        string = string+ str(i)+' '
    print string
print0to8()
print 

def cords():
    for i in range(0,9):
        string = ''
        if(i==3 or i==6):
            print
        for j in range(0,9):
            if(j==3 or j==6):
                string = string + ' '
            string = string + str(i)+','+str(j)+ ' '
        print string
cords()
print

def rowFinder(row):
    string = ''
    for i in range(0,9):
        string = string + str(row)+','+str(i)+ ' '
    print string
row = raw_input('Enter row # ==> ')
rowFinder(row)
print

def columnFinder(column):
    string = ''
    for i in range(0,9):
        string = string + str(i)+','+str(column)+ ' '
    print string
column = raw_input("Enter column # ==> ")
columnFinder(column)
print

def boxFinder(row,column):
    row-=1
    column-=1
    for i in range(0,3):
        string = ''
        for j in range(0,3):
            if(row==0 and column==0):
                string = string + str(i)+','+str(j)+ ' '
            elif(row==0 and column!=0):
                val1 = j + 3*column
                string = string + str(i)+','+str(val1)+ ' '
            elif(row!=0 and column==0):
                val1 = i + 3*row
                string = string + str(val1)+','+str(j)+ ' '
            else:
                val1 = i +3*row
                val2 = j +3*column
                string = string +str(val1)+','+str(val2)+ ' '
        print string
row = raw_input("Enter row # ==> ")
row = int(row)
column = raw_input("enter column # ==> ")
column = int(column)
boxFinder(row,column)
            
    