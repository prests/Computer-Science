import webbrowser
webbrowser.open("http://hackertyper.com/")
