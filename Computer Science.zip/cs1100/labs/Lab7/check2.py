'''
def parse_line(text_line):
    text_line = text_line.split('/',3)
    return text_line

text_line = raw_input("enter text line ==> ")
text_line = parse_line(text_line)
print text_line

'''

def get_line(fname,parno,lineno):
    i=1
    j=1
    emptyspace = False
    for line in open(fname):
        if(line!='\n' and emptyspace == True):
            j+=1
            i=1
            emptyspace = False
        if(line=='\n'):
            emptyspace=True
        if(j==parno):
            if(i==lineno):
                text_line = line
                break
        i+=1
    return text_line
fname = raw_input('Please file number ==> ')
fname = str(fname+'.txt')
parno = raw_input('Please enter paragraph number ==> ')
parno = int(parno)
lineno = raw_input('Please enter the line number ==> ')
lineno = int(lineno)
text_line= get_line(fname,parno,lineno)
print text_line