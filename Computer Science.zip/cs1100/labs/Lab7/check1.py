def parse_line(text_line):
    text_line = text_line.split('/',3)
    try:
        x = int(text_line[0])
        x = int(text_line[1])
        x = int(text_line[2])
    except:
        text_line = 'None'    
    return text_line

text_line = raw_input("enter text line ==> ")
text_line = parse_line(text_line)
print text_line