def parse_line(text_line):
    text_line = text_line.split('/',3)
    try:
        x = int(text_line[0])
        x = int(text_line[1])
        x = int(text_line[2])
    except:
        text_line = 'wrong pointer'
    return text_line

def get_line(fname,parno,lineno):
    lin=1
    par=1
    emptyspace = False
    for line in open(fname):
        if(line!='\n' and emptyspace == True):
            par+=1
            lin=1
            emptyspace = False
        if(line=='\n'):
            emptyspace = True
        if(par==parno):
            if(lin==lineno):
                text_line = line
                return text_line
        if(lin>lineno and par>parno):
            break
        lin+=1
    text_line = 'wrong pointer'
    return text_line

fname = raw_input('Please file number ==> ')
fname = str(fname+'.txt')
parno = raw_input('Please enter paragraph number ==> ')
parno = int(parno)
lineno = raw_input('Please enter the line number ==> ')
lineno = int(lineno)

text_line= get_line(fname,parno,lineno)
text_line= parse_line(text_line)
finalfile =  open("program.py","w")
while(True):
    print text_line
    if(text_line == 'wrong pointer' or text_line[3]=='END\n'):
        break
    else:
        command = text_line[3]
        finalfile.write(command)
        text_line=get_line(str(text_line[0]+'.txt'),int(text_line[1]),int(text_line[2]))
        text_line=parse_line(text_line)
finalfile.close()
import program
print program
