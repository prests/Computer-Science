from Date import *

f= open('Birthdays.txt')
allbirthdays=[]
months={}
for line in f:
    
    temp = line.split(' ')
    temp[2]=temp[2].strip('\n')
    allbirthdays.append(Date(temp[0],temp[1],temp[2]).__str__())
    if(temp[1] in months):
        months[temp[1]]=months.get(temp[1])+1
    else:
        months[temp[1]]=1
        
mostpopular='',0
for i in months:
    if(months.get(i)>mostpopular[1]):
        mostpopular=(i,months.get(i))
print
print "Most popular month: ",month_names[int(mostpopular[0])]    
print "Earliest date: ",min(allbirthdays)
print "Latest date: ",max(allbirthdays)
    
    
        
    