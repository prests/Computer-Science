def get_words(desc):
    desc = desc.replace('.',' ').replace('(',' ').replace(')',' ').replace('"',' ').replace(',',' ')
    new_list = []
    new_set = set()
    temp = ''
    for i in range(0,len(desc)):
        if(desc[i]==' '):
            if(temp.isalpha()==True):
                new_list.append(temp)
                temp = ''
        if(desc[i].isalpha()==True and desc[i]!=' '):
            temp += desc[i]
    for i in range(0,len(new_list)):
        new_list[i]= new_list[i].lower()
        if(len(new_list[i])>=4):
            new_set.add(new_list[i])
    return new_set

desc = raw_input('enter club => ')
desc = desc.replace(' ','')
desc =desc.lower()
if(desc == 'quiddatchclub'):
    filename = 'qc.txt'
elif(desc == 'engineeringambassadors'):
    filename = 'ea.txt'
elif(desc == 'chineseamericanstudentsassociation'):
    filename = 'csa.txt'
else:
    filename = desc+'.txt'
line = open(filename)
temp = line.readline()
temp = temp.strip().split('|')
replace_set=get_words(temp[1])


desc2 = raw_input('enter club => ')
desc2 = desc2.replace(' ','')
desc2 = desc2.lower()
if(desc2 == 'quiddatchclub'):
    filename2 = 'qc.txt'
elif(desc2 == 'engineeringambassadors'):
    filename2 = 'ea.txt'
elif(desc2 == 'chineseamericanstudentsassociation'):
    filename2 = 'csa.txt'
else:
    filename2 = desc2+'.txt'
line2 = open(filename2)
temp2 = line2.readline()
temp2 = temp2.strip().split('|')
replace_set2=get_words(temp2[1])
    
newthing = replace_set.intersection(replace_set2)
print 'Same',newthing
onlyin1 = replace_set.difference(replace_set2)
print 'only in first',onlyin1
onlyin2 = replace_set2.difference(replace_set)
print 'only in second',onlyin2

