def get_words(desc):
    desc = desc.replace('.',' ').replace('(',' ').replace(')',' ').replace('"',' ').replace(',',' ')
    new_list = []
    new_set = set()
    temp = ''
    for i in range(0,len(desc)):
        if(desc[i]==' '):
            if(temp.isalpha()==True):
                new_list.append(temp)
                temp = ''
        if(desc[i].isalpha()==True and desc[i]!=' '):
            temp += desc[i]
    for i in range(0,len(new_list)):
        new_list[i]= new_list[i].lower()
        if(len(new_list[i])>=4):
            new_set.add(new_list[i])
    return new_set

def compare(replace_set,replace_set2):
    newthing = replace_set.intersection(replace_set2)
    onlyin1 = replace_set.difference(replace_set2)
    onlyin2 = replace_set2.difference(replace_set)
    return len(newthing)

desc = raw_input('enter club => ')
desc = desc.replace(' ','')
desc =desc.lower()
if(desc == 'quiddatchclub'):
    filename = 'qc.txt'
elif(desc == 'engineeringambassadors'):
    filename = 'ea.txt'
elif(desc == 'chineseamericanstudentsassociation'):
    filename = 'casa.txt'
else:
    filename = desc+'.txt'
line = open(filename)
temp = line.readline()
temp = temp.strip().split('|')
replace_set=get_words(temp[1])

similarity_list = []
for line in open('allclubs.txt'):
    temp2 = line.strip().split('|')
    if(desc!=temp2[0].lower().replace(' ','')):
        temp_replace = get_words(temp2[1])
        similarity_list.append((int(compare(replace_set,temp_replace)), temp2[0]))

similarity_list.sort(reverse=True)
for i in range(0,5):
    print similarity_list[i][1]