leng = 12
width = 10
height = 6
face1 = leng * width +
face2 = leng * height
face3 = width * leng
area = 2*face1 + 2*face2 + 2*face3
prnt "Area of the rectangular solid with"
print "length", leng
print "width ", width
print "height", height
print "is", area, "cubic units"
