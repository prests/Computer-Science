base10 = 128
base2 = base10*10**9/2**30
difference = base10-base2
print base10, "in base 10 is actually", base2, "in base 2,", difference, "less than advertised" 