JupDistance = 483632000
JupDiameter = 88846
JupRadius = JupDiameter/2
EarDistance = 92957100
EarDiameter = 7926
EarRadius = EarDiameter/2
DistanceRatio = JupDistance*1.0/EarDistance
print "Jupiter is", DistanceRatio, "times farther from the Sun than he Earth is."
pi = 3.14
JupVolume = (4.0/3.0)*pi*(JupRadius**3)
EarVolume = (4.0/3.0)*pi*(EarRadius**3)
VolumeRatio = 1.0*JupVolume/EarVolume
print "Jupiter's volume is larger than the volume of earth by a factor of", VolumeRatio
SpeedOfLightSec = 186000
SpeedMin = SpeedOfLightSec/60
EarthToSunSec = EarDistance/SpeedOfLightSec
EarthToSunMin = EarthToSunSec/60
EarthToSunSec = EarthToSunSec%60
print "It takes", EarthToSunMin, "Minutes and", EarthToSunSec, "seconds to travel from the sun to the earth"
JupToSunSec = JupDistance/SpeedOfLightSec
JupToSunMin = JupToSunSec/60
JupToSunSec = JupToSunSec%60
print "It takes", JupToSunMin, "Minutes and", JupToSunSec, "seconds to travel from the sun to the earth"