class Ball(object):
    def __init__(self,posx,posy,dx,dy,r,color):
        self.posx=posx
        self.posy=posy
        self.dx=dx
        self.dy=dy
        self.radius=r
        self.color=color
        
    def position(self):
        return (self.posx,self.posy)
    
    def move(self):
        self.posx+=self.dx
        self.posy+=self.dy
        
    def bounding_box(self):
        return (self.posx-self.radius,self.posy-self.radius,self.posx+self.radius,self.posy+self.radius) 
    
    def get_color(self):
        return self.color
    
    def some_inside(self,maxx,maxy):
        if self.posx+self.radius<0 or self.posx-self.radius>maxx or self.posy+self.radius<0 or self.posy-self.radius>maxy:
            return False
        else:
            return True
        
    def check_and_reverse(self,maxx,maxy):
        if(self.posx-self.radius<0 or self.posx+self.radius>maxx):
            self.dx=-self.dx
        if(self.posy-self.radius<0 or self.posy+self.radius>maxy):
            self.dy=-self.dy