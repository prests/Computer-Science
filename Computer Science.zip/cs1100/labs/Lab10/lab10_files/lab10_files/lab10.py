""" This is the skeleton for your lab 10. We provide a function
    here to show the use of nose.

"""

import math as m
import random as r
import time as t

def closest1(L1):
    if(len(L1)<2):
        return (None, None)
    x = L1[0]
    y = L1[1]
    for i in range(len(L1)):
        for j in range(len(L1)):
            if(m.fabs(L1[i]-L1[j])<m.fabs(x-y) and j!=i):
                x = L1[i]
                y = L1[j]
    if(x > y):
        temp = x
        x = y
        y = temp
    return (x, y)
    
def closest2(L1):
    L1 = sorted(L1)
    i = 0
    j = 1
    x = L1[i]
    y = L1[j]
    while(j<len(L1)):
        if(m.fabs(L1[i]-L1[j])<m.fabs(x-y)):
            x = L1[i]
            y = L1[j]
        i += 1
        j += 1
    return (x, y)

def run_time(L1):
    s1 = t.time()
    (x1,y1) = closest1(L1)
    t1 = t.time() - s1
    print 'Ver 1: numbers (%f.1,%f.1); time %.3f seconds' %(x1,y1,t1)
    
    s2 = t.time()
    (x2,y2) = closest2(L1)
    t2 = t.time() - s2
    print 'Ver 2: numbers (%f.1,%f.1); time %.3f seconds' %(x2,y2,t2)
def random_list(n):
    L1 = []
    for i in range(n):
        L1.append(r.uniform(0.0, 1000.0))
    return L1
        
def addone(x):
    return x+1

if __name__ == '__main__':
    L1 = [15.1, -12.1, 5.4, 11.8, 17.4, 4.3, 69.9]
    print L1
    (x,y) = closest1(L1)
    print x, y
    (x2,y2) = closest2(L1)
    print x2, y2
    n = int(raw_input('100, 1,000, or 10,000 size => '))
    L2 = random_list(n)
    run_time(L2)