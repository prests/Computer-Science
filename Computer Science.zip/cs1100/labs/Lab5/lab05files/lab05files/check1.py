import lab05_util

def print_info(restaurant):
    cat = str('('+restaurant[5]+')')
    print restaurant[0],cat
    addr = restaurant[3]
    addr = addr.split("+")
    print '\t',addr[0]
    print '\t',addr[1]
    tuavg= restaurant[6]
    avg = int(tuavg[0]+tuavg[1]+tuavg[2]+tuavg[3]+tuavg[4]+tuavg[5]+tuavg[6])/float(6)
    print 'Average score: %.2f'%avg
    

restaurants = lab05_util.read_yelp('yelp.txt')
print restaurants[0]
print_info(restaurants[0])