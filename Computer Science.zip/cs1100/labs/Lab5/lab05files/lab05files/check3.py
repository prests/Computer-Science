import lab05_util
import webbrowser

def print_info(restaurant):
    cat = str('('+restaurant[5]+')')
    print restaurant[0],cat
    addr = restaurant[3]
    addr = addr.split("+")
    print '\t',addr[0]
    print '\t',addr[1]
    tuavg= restaurant[6]
    tuavglen = len(tuavg)
    temp = 0
    avgsum = 0
    if(tuavglen<=3):
        while(temp<tuavglen):
            avgsum = int(avgsum + tuavg[temp])
            temp+=1
    else:
        temp+=1
        tuavglen-=1
        while(temp<tuavglen):
            avgsum = int(avgsum + tuavg[temp])
            temp+=1
    avg = avgsum/float(tuavglen)
    if(0<=avg and avg<2):
        print "This restaurant is rated bad, based on", tuavglen, "reviews."
    elif(2<=avg and avg<3):
        print "This restaurant is rated average, based on", tuavglen, "reviews."
    elif(3<=avg and avg<4):
        print "This restaurant is rated above average, based on", tuavglen, "reviews."
    elif(4<=avg and avg<5):
        print "This restaurant is rated very good, based on", tuavglen, "reviews"
    

restaurants = lab05_util.read_yelp('yelp.txt')
ids = raw_input('Enter an ID between 1 and 155 ==> ')
ids = int(ids)
ids-=1
if(ids<0 or ids>154):
    print "Warning"
else:
    print_info(restaurants[ids])
placeholder = restaurants[ids]
print 'What would you like to do next?'
print '1. Visit the homepage'
print '2. Show on Google Maps'
print '3. Show direction to this restaurant'
choice = raw_input("Your choice (1-3)? ==> ")
choice = int(choice)
if(choice ==1):
    webbrowser.open('http://xkcd.com/1319')
elif(choice ==2):
    website = str('http://www.google.com/maps/place/'+placeholder[3])
    webbrowser.open(website)
elif(choice ==3):
    website = str('http://www.google.com/maps/dir/110 8th Street Troy NY/'+placeholder[3])
    webbrowser.open(website)

                