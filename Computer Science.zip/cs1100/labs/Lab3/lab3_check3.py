bpop=100
fpop = 10

def popb(bpop,fpop):
    bpop_next = int((10*bpop)/(1+0.1*bpop)-0.05*bpop*fpop)
    bpop_next = max(0,bpop_next)
    return bpop_next
def popf(bpop,fpop):
    fpop_next = int(0.4 * fpop + 0.02 * fpop * bpop)
    fpop_next = max(0,fpop_next)
    return fpop_next
years = raw_input('Number of years=> ')
temp = 0
if(years==0):
    print ' '
else:
    print bpop, fpop
while(temp<int(years)-1):
    temp1=bpop
    bpop = popb(bpop,fpop)
    fpop = popf(temp1,fpop)
    print bpop, fpop
    temp=temp+1
