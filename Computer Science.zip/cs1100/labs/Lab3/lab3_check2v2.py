def soccer():
    country = raw_input("Insert country name ==> ")
    wins = raw_input("Insert number of wins ==> ")
    losses = raw_input("Insert number of losses ==> ")
    draws = raw_input("Insert number of draws ==> ")
    goalsfor = raw_input("Insert numbers of goals for ==> ")
    goalsagainst = raw_input("Insert number of goals against ==> ")
    totalpoints = int(wins)*3+int(draws)
    goaladv = int(goalsfor)-int(goalsagainst)
    print country
    print "Win:", wins, "Lose:", losses, "Draw:", draws
    print "Total number of points:", totalpoints, "Goal advantage:", goaladv

soccer()
soccer()
soccer()
soccer()