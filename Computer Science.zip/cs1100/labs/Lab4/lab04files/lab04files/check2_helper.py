from PIL import Image

def make_square(image):
    Height = image.height
    Width = image.width
    if(Height>Width):
        im2 = image.resize((Width,Width))
    elif(Width>Height):
        im2 = image.resize((Height,Height))
    return im2

im = Image.open('1.jpg')
imsq = make_square(im)
imsq.show()