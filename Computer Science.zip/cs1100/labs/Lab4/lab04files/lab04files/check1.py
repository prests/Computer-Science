from PIL import Image
import panoramio as pan

im1 = Image.new('RGB',(512,512),'white')
im2 = Image.open('ca.jpg')
im2 = im2.resize((256,256))
im1.paste(im2,(0,0))
im3 = Image.open('im.jpg')
im3 = im3.resize((256,256))
im1.paste(im3,(256,0))
im4 = Image.open('hk.jpg')
im4 = im4.resize((256,256))
im1.paste(im4,(0,256))
im5 = Image.open('bw.jpg')
im5 = im5.resize((256,256))
im1.paste(im5,(256,256))
im1.show()

def make(im1,im2,im3,im4,num):
    ims = Image.new("RGB",(512,512),"white")
    a = pan.openphoto(im1)
    b = pan.openphoto(im2)
    c = pan.openphoto(im3)
    d = pan.openphoto(im4)
    a = a.resize((256,256))
    b = b.resize((256,256))
    c = c.resize((256,256))
    d = d.resize((256,256))
    ims.paste(a,(0,0))
    ims.paste(b,(ims.width/2,0))
    ims.paste(c,(0,ims.height/2))
    ims.paste(d,(ims.width/2,ims.height/2))
    ims.save("ims.jpg")
    return ims