import panoramio as pan
import check1 as part1
while(True):
    address = raw_input('Enter an address ==> ')
    urls = pan.getPhotos(address,4)
    for i in range(0,4):
        try:
            im1=pan.openphoto(urls[i])
            im1.show()
            if(i==3):
                part1.make(urls[0],urls[1],urls[2],urls[3],0).show()
        except:
            print "can't find enough pictures"
            break
