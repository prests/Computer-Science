print '*'*10
print '*'*2, 'spam', '*'*2
print '*'*10


word = raw_input("put in a four letter word==> ")
print '*'*10
print '*'*2, word, '*'*2
print '*'*10


check3word = raw_input('put in a word==> ')
size = len(check3word)
print '*'*(size+6)
print '*'*2, check3word, '*'*2
print '*'*(size+6)


firstname = raw_input('enter your first name==> ')
lastname = raw_input('enter your last name==> ')+'!'
if(len(firstname)>len('hello,')):
    if(len(firstname)>len(lastname)):
        size = len(firstname)
else:
    if(len(lastname)>len('hello')):
        size = len(lastname)
    else:
        size = len('hello,')
print '*'*(size+6)
print str('*'*2+' '+ 'hello,'+ ' '*((size)-(len('hello,'))+1)+'*'*2)
print str('*'*2+' '+ firstname+ ' '*((size)-(len(firstname))+1)+'*'*2)
print str('*'*2+' '+ lastname+ ' '*((size)-(len(lastname))+1)+'*'*2)
print '*'*(size+6)
